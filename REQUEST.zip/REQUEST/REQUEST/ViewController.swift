//
//  ViewController.swift
//  REQUEST
//
//  Created by MACOS on 6/13/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet var tbl: UITableView!
    @IBOutlet var txtName: UITextField!
    @IBOutlet var txtAdd: UITextField!
    
    var final = [Any]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let str = String("http://localhost/test/select.php")
    
        let url = URL(string: str!)
        
        let request = URLRequest(url: url!)
        
        let session = URLSession.shared
        
        let datatask = session.dataTask(with: request, completionHandler: {(data,res,err) in
            
            
            DispatchQueue.main.sync {
                do
                {
                    let dic = try JSONSerialization.jsonObject(with: data!, options: []) as! [Any]
                    
                    for item in dic
                    {
                        self.final.append(item)
                        self.tbl.reloadData()
                    }
                }
                catch
                {
                    
                }
            }
         //let str1 = String(data: data!, encoding: String.Encoding.utf8)
         //   print(str1 ?? "")
            
        })
        datatask.resume()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return final.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        let dicfinal = final[indexPath.row] as! [String:Any]
        
        cell?.textLabel?.text = dicfinal["Name"] as! String
        cell?.detailTextLabel?.text = dicfinal["Address"] as! String
        
        return cell!
    }

    @IBAction func btnInsert(_ sender: Any) {
        let str = String("http://localhost/test/insert1.php?Name=\(txtName.text!)&Address=\(txtAdd.text!)")
        
        let url = URL(string: str!)
        
        let request = URLRequest(url: url!)
        
        let session = URLSession.shared
        
        let datatask = session.dataTask(with: request, completionHandler: {(data,res,err) in
            
             let str1 = String(data: data!, encoding: String.Encoding.utf8)
            print(str1 ?? "")
        })
        datatask.resume()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

